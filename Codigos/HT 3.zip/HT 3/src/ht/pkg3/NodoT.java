/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg3;

/**
 *
 * @author Daniel
 */
public class NodoT {
   
    private int dato;
    private NodoT sig, abajo;
    private boolean b;

    public NodoT() {
        this.dato = 0;
        this.sig = null;
        this.abajo = null;
        b = false;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public NodoT getSig() {
        return sig;
    }

    public void setSig(NodoT sig) {
        this.sig = sig;
    }

    public NodoT getAbajo() {
        return abajo;
    }

    public void setAbajo(NodoT abajo) {
        this.abajo = abajo;
    }

    public boolean isB() {
        return b;
    }

    public void setB(boolean b) {
        this.b = b;
    } 
}


