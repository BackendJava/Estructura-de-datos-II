/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg3;

/**
 *
 * @author Daniel
 */
public class Arbol_B {
   public NodoM padre;
    public NodoM[] mv;
    public int t;

    public Arbol_B() {
        this.t = 0;
        this.padre = null;
    }

    public int getT() {
        return t;
    }

    public void padre(int d, int ind) {
        NodoM temp = new NodoM(d, ind);
        padre = temp;
    }

    public void ingresar(int dato, int ind) {
        if (padre == null) {
            padre(dato, ind);
        } else {
            insertar(dato, ind, padre);
        }
        t++;
    }

    public void insertar(int dato, int in, NodoM z) {
        int ind = (in - 1) / 2;
        if (z.getIndice() == ind) {
            NodoM temp = new NodoM(dato, in);
            if (z.getIzq() == null) {
                z.setIzq(temp);
                if (temp.getDato() < z.getDato()) {
                    int temp2 = z.getDato();
                    z.setDato(temp.getDato());
                    temp.setDato(temp2);
                }
            } else {
                z.setDer(temp);
                if (temp.getDato() < z.getDato()) {
                    int temp2 = z.getDato();
                    z.setDato(temp.getDato());
                    temp.setDato(temp2);
                }
            }
        } else {
            if (z.getIzq() != null) {
                insertar(dato, in, z.getIzq());
                if (z.getIzq().getDato() < z.getDato()) {
                    int temp2 = z.getDato();
                    z.setDato(z.getIzq().getDato());
                    z.getIzq().setDato(temp2);
                }
            }
            if (z.getDer() != null) {
                insertar(dato, in, z.getDer());
                if (z.getDer().getDato() < z.getDato()) {
                    int temp2 = z.getDato();
                    z.setDato(z.getDer().getDato());
                    z.getDer().setDato(temp2);

                }
            }
        }
    }

    public void toString1(NodoM n) {
        mv = new NodoM[t];
        int ct = 0;
        if (n != null) {
            mv[ct].setDato(n.getDato());
            toString1(n.getIzq());
            toString1(n.getDer());
            ct++;
        }
    }
    public void mostrar(NodoM padre){
        System.out.println(padre.getDato());
        System.out.println(padre.getDer().getDato());
    }

   
}







