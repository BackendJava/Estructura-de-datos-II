/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg3;

import java.util.Scanner;

/**
 *
 * @author Daniel
 */
public class HT3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int op, indice, valores, dato;
        boolean fin = false;
        Scanner leer = new Scanner(System.in);
        Arbol_B m = new Arbol_B();
        m.toString1(m.padre);
        System.out.println("Ingrese indice: ");
        indice = leer.nextInt();
            
        while(!fin){
            System.out.println("Ingrese una opcion");    
            System.out.println("1. Ingresar valores ");
            System.out.println("2. Salir");
            op = leer.nextInt();
            switch (op) {
                case 1:
                    System.out.println("Cuantos valores ingresara ");
                    valores = leer.nextInt();
                    for (int i = 1; i <= valores; i++) {
                        System.out.print(i + ".Ingrese valor: ");
                        dato = leer.nextInt();
                        m.ingresar(dato, indice);
                    }
                    m.mostrar(m.padre);
                    break;
                case 2:
                    fin = true;
                    break;
            }
        }    
         
    }
}














