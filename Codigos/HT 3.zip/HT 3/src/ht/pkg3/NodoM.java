/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg3;

/**
 *
 * @author Daniel
 */
public class NodoM {
     public NodoM izq;
 public NodoM der;
 private int dato, indice;

    public NodoM(int dato, int i) {

        this.indice = i;
        this.dato = dato;
        this.der = null;
        this.izq = null;
    } 

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public NodoM getIzq() {
        return izq;
    }

    public void setIzq(NodoM izq) {
        this.izq = izq;
    }

    public NodoM getDer() {
        return der;
    }

    public void setDer(NodoM der) {
        this.der = der;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }
    
}



