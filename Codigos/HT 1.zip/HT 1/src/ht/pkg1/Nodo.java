/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg1;

/**
 *
 * @author Daniel
 */
public class Nodo {
    private int valor;
    private Nodo hd;
    private Nodo hi;
    
    private void NodoArbol(){
            hd = null;
            hi = null;
            valor = 0;
        }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getHd() {
        return hd;
    }

    public void setHd(Nodo hd) {
        this.hd = hd;
    }

    public Nodo getHi() {
        return hi;
    }

    public void setHi(Nodo hi) {
        this.hi = hi;
    }
    
}





