/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg1;
import java.util.Scanner;
/**
 *
 * @author Daniel
 */
public class HT1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner (System.in);
        Arbol arbolito = new Arbol ();
        boolean fin = false;
        int opcion, valor;
        while(!fin){
            System.out.println("\n");
            System.out.println("1. Ingresar valor");
            System.out.println("2. Mostrar (PREORDEN)");
            System.out.println("3. Mostrar (INORDEN)");
            System.out.println("4. Mostrar (POSTORDEN)");
            System.out.println("5. Mostrar Altura Del Arbol");
            System.out.println("6. Comprobar el Valor de Hoja");
            System.out.println("7. Imprimir las hojas");
            System.out.println("8. Eliminar un nodo");
            System.out.println("9. Salir");
            opcion = teclado.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.println("Ingrese un valor");
                    valor = teclado.nextInt();
                    arbolito.setRaiz(arbolito.insertar(arbolito.getraiz(),valor));
                    break;
                case 2:
                    System.out.println("*******PREORDEN*******");
                    arbolito.preOrder(arbolito.getraiz());
                    break;
                case 3:
                    System.out.println("*******INORDEN*******");
                    arbolito.inOrder(arbolito.getraiz());
                    break;
                case 4:
                    System.out.println("*******POSTORDEN*******");
                    arbolito.posOrder(arbolito.getraiz());
                    break;
                case 5:
                    System.out.println("*******Altura******");
                    System.out.println("La altura del arbol es: "+ arbolito.altura(arbolito.getraiz()));
                    break;
                case 6:
                    System.out.println("*******Comprobar si es Hoja*******");
                    System.out.println("Ingrese el numero:");
                    valor = teclado.nextInt();
                    if (arbolito.existe(valor,arbolito.getraiz()) == true) {
                        if (arbolito.comprobar_hoja(arbolito.buscar(valor,arbolito.getraiz()))==true) {
                            System.out.println("El numero " + valor + " si es hoja");       
                        }
                        else{
                            System.out.println("El numero " + valor + " no es hoja");
                        }                        
                    }else{
                        System.out.println("el valor ingresado no existe");
                    }
                    break;
                case 7:
                    System.out.println("*******Imprimir las Hojas*******");
                    arbolito.hoja_si_no(arbolito.getraiz());
                    break;
                case 8:
                    System.out.println("******Eliminar Nodo******");
                    System.out.println("Que numero desea eliminar");
                        valor = teclado.nextInt();  
                        if (arbolito.existe(valor, arbolito.getraiz()) == true) {
                            if(arbolito.eliminar(valor)==false){
                                System.out.println("Elemento no encontrado");
                            }
                            else{
                                System.out.println("nodo eliminado");
                            }    
                        }
                        else {
                            System.out.println("el valor ingresado no existe");
                        }
                    break;
                case 9:
                    fin = true;
                    break;
            }
        }
    } 
}












