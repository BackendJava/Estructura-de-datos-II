/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ht.pkg1;
import java.util.HashSet;
import java.util.Set;
/**
 *
 * @author Daniel
 */
public class Arbol {
    private Nodo raiz;
    public int niv = 0;
    
    public Nodo getraiz(){
        return raiz;
    }
    
    public void setRaiz(Nodo raiz) {
        this.raiz = raiz;
    }
    
    public int gett(){
        return raiz.getValor();
    }
     
    public Nodo insertar(Nodo nodo, int valor){
         Nodo nuevo = new Nodo();
            nuevo.setValor(valor);
            
        if (nodo == null) {
            nuevo.setHd(null);
            nuevo.setHi(null);
            nodo = nuevo;
        }
        else {    
            if (valor > nodo.getValor()) {
                nodo.setHd(insertar(nodo.getHd(),valor));
            }
            else{
               nodo.setHi(insertar(nodo.getHi(),valor));
            }
        }
        return nodo;
    }
 
    public void preOrder(Nodo nodo){
        if (nodo!=null) {
            System.out.print(nodo.getValor() + " ");
            preOrder(nodo.getHi());
            preOrder(nodo.getHd());
        }
    }
 
    public void inOrder(Nodo nodo){
        if (nodo!=null) {

            inOrder(nodo.getHi());
            System.out.print(nodo.getValor() + " ");  
            inOrder(nodo.getHd());
        }
    }
 
    public void posOrder(Nodo nodo){
        if (nodo!=null) {
           posOrder(nodo.getHd());
            posOrder(nodo.getHi());
            System.out.print(nodo.getValor() + " ");
        }
    }
    
    public boolean existe(int valor, Nodo nodo){
         boolean verdad=false;
        if (nodo != null) {
            if (valor == nodo.getValor()) {
                verdad = true;
            }
            else {
                if (valor < nodo.getValor()) {
                    verdad = existe(valor, nodo.getHi());
                }
                else {
                    verdad = existe(valor, nodo.getHd());
                }
            }
        }
        return verdad;
    }
   
    public int altura(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        else {
            return (1 + Math.max((altura(nodo.getHi())), (altura(nodo.getHd()))));
        }
    }
     
     
     
     public Nodo buscar(int valor, Nodo nodo){
        Nodo auxiliar = null;
        if (nodo!=null) {
            if (valor == nodo.getValor()) {
            auxiliar = nodo;
            }
            else {
                niv++;
                if (valor < nodo.getValor()) {
                    auxiliar = buscar(valor, nodo.getHi());
                }
                else {
                    auxiliar = buscar(valor, nodo.getHd());
                }
            }
        }
        return auxiliar;
    }
    
    public int nivel(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        else {
            return (Math.max((altura(nodo.getHi())), (altura(nodo.getHd()))));
        }
    }
     

    public void hoja_si_no(Nodo nodo){
        if (nodo!=null) {            
            if(nodo.getHd()==null && nodo.getHi()==null){
            System.out.print(nodo.getValor() + " ");
           }
            else {
                hoja_si_no(nodo.getHi());
                hoja_si_no(nodo.getHd());
            }
        }
    }
    
    public boolean comprobar_hoja(Nodo nodo){     
        boolean hoja;
        if(nodo.getHd()==null && nodo.getHi()==null){
            hoja=true;
        }
        else{ 
            hoja=false;
        }
        return hoja;
    }
    //metodo para eliminar un nodo 
    public boolean eliminar(int dato){
        Nodo auxiliar = raiz;
        Nodo padre = raiz;
        boolean eshi = true;
        while(auxiliar.getValor()!=dato){
            padre = auxiliar; 
            if(dato<auxiliar.getValor()){
                eshi = true;
                auxiliar = auxiliar.getHi();
            }
            else{ 
                eshi = false;
                auxiliar = auxiliar.getHd();
            }
            if(auxiliar==null){ 
                return false;
            }
        } // fin while
        if(auxiliar.getHi()==null && auxiliar.getHd()==null){
            if(auxiliar==raiz){
                raiz = null;
            }
            else if (eshi){
                padre.setHi(null);
            }
            else{
                padre.setHd(null);
            }
        }
        else if(auxiliar.getHd()==null){
            if(auxiliar==raiz){
                raiz = auxiliar.getHi();
            }
            else if (eshi){
                padre.setHi(auxiliar.getHi());
            }
            else{
                padre.setHd(auxiliar.getHi());
            }
        }
        else if(auxiliar.getHi()==null){
            if(auxiliar==raiz){
                raiz = auxiliar.getHd();
            }
            else if (eshi){
                padre.setHi(auxiliar.getHd());
            }
            else{
                padre.setHd(auxiliar.getHi());         
            }
        }
        else{
            Nodo reemplazo = obtenernodoreemplazo(auxiliar);
            if(auxiliar==raiz){
                raiz= reemplazo;
            }
            else if(eshi){
                padre.setHi(reemplazo);
            } 
            else{
            padre.setHd(reemplazo);
            } 
            reemplazo.setHi(auxiliar.getHi());
        }
            return true;
    }
         
    //metodo encargado de devolvernos el nodo reemplazo     
    public Nodo obtenernodoreemplazo(Nodo nodoreem){
         
        Nodo reemplazarpadre = nodoreem;
        Nodo reemplazo = nodoreem;
        Nodo auxiliar = nodoreem.getHd();
        while(auxiliar!=null){
            reemplazarpadre = reemplazo;
            reemplazo = auxiliar;
            auxiliar = auxiliar.getHi();
        }
        if(reemplazo!=nodoreem.getHd()){ 
            reemplazarpadre.setHi(reemplazo.getHd()); 
            reemplazo.setHd(nodoreem.getHd());
        }
        System.out.println("el nodo reemplazo es " + reemplazo.getValor());
        return reemplazo;
    }
}














