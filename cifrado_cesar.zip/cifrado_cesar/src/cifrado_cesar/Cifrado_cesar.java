/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cifrado_cesar;

/**
 *
 * @author Usuario
 */
public class Cifrado_cesar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        cifrar cifrar_cadena = new cifrar();
         String cadena = cifrar_cadena.Cifrar(3,"hola mundo como estan");
         String cadena2 = cifrar_cadena.Decifrar(3, cadena);
        System.out.println("cadena cifrada: "+cadena);
        System.out.println("cadena decifrada: "+cadena2);
        
          }
    
}
