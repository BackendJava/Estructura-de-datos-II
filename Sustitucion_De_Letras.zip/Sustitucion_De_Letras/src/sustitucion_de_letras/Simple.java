/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustitucion_de_letras;

import java.util.Random;

/**
 *
 * @author Usuario
 */
public class Simple {
    private String vector[];
    private String alfabeto = " abcdefghijklmnñopqrstuvwxyz";
    private int periodo;

    public Simple(int periodo) {
        this.periodo = periodo;
        this.vector = new String[periodo];
        System.out.println(alfabeto.length());
        for(int i=0;i<periodo;i++){
            vector[i]="";
        }
        LlenarVector();
    }
    //se crean los alfabetos con las letras desordenadas
    private void LlenarVector(){
        int numero,contador=0, num_aux;
        char caracter;
        for(int i=0;i<periodo;i++){// se recorre el vector con los alfabetos con las letras desordenadas 
            contador = 0;
           while(contador<29&&contador!=28){//el contador debe de llegar a 28 caracteres ya que es el numero de caracteres que tiene cada alfabeto 
           numero =(int)(Math.random()*28); // se busca un numero entre 0 a 28 
            
           caracter = alfabeto.charAt(numero);// se busca el caracter en el alfabeto 
           
           num_aux = vector[i].indexOf(caracter);// se obtiene la 
           if(num_aux == -1){
            vector[i]+=caracter;  
            contador++;
           }
           
           } 
        }  
    }
    public String Encriptar(String cadena){
        String cadena_encrip = "";
        char caracter;
        int contador = 0,posicion;
        for(int i=0; i<cadena.length();i++){
          
         caracter = cadena.charAt(i);//obtener un caracter de la cadena a encriptar o cifrar 
         posicion = alfabeto.indexOf(caracter);//obtener la posicion en el alfabeto normal 
         if(contador == periodo){//ver que el contador este en el rango de las posiciones del vector 
             contador = 0;
         }
           cadena_encrip+=vector[contador].charAt(posicion);//se busca el caracter que este en la misma posicion del caracter en curso en el alfabeto de turno 
           contador++;
        }
        return cadena_encrip;
    }
    
    public String Desencriptar(String cadena){
        String cadena_des = "";
        char caracter;
        int contador = 0,posicion;
       
        for(int i=0;i<cadena.length();i++){
            if(contador == periodo){ //se ve que el contador no sea igual a periodo 
                contador = 0;
            }
            caracter = cadena.charAt(i);//se encuentra el caracter en la posicion actual 
            posicion = vector[contador].indexOf(caracter);//se encuentra la posicion del caracter en el vector actual segun el periodo 
            cadena_des+=alfabeto.charAt(posicion);//se encuentra el caracter en el alfabeto normal y que concatena en un string 
            contador++; //se incremente el contador 
            
        }
        
        return cadena_des; 
    }
    
    public String[] getVector() {
        return vector;
    }

    public void setVector(String[] vector) {
        this.vector = vector;
    }

    public String getAlfabeto() {
        return alfabeto;
    }

    public void setAlfabeto(String alfabeto) {
        this.alfabeto = alfabeto;
    }

    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }
    
}
