/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sustitucion_de_letras;

import java.util.Random;

/**
 *
 * @author Usuario
 */
public class Sustitucion_De_Letras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
           Simple simple = new Simple(1);
           String vector[] = simple.getVector(), prueba = "hola";
           int num;
           num = prueba.indexOf("");
           System.out.println(num);       
           for(int i=0;i<vector.length;i++){
               System.out.println("vector "+i+": "+vector[i]);
               
           }
           String cadena = "buenas";
           System.out.println("Cadena a encriptar: "+cadena);
           String cadena_encrip = simple.Encriptar(cadena), cadena_des;
           System.out.println("Cadena encriptada: "+cadena_encrip);
           cadena_des = simple.Desencriptar(cadena_encrip);
           System.out.println("Cadena Desencriptada: "+cadena_des);
    }
    
}
