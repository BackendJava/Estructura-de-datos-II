/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parcial_2;

import java.util.Scanner;

/**
 *
 * @author datos
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
        int n, n2, temp;
       
        n = input.nextInt();

        
        Rle rle = new Rle();
       
        int opcion, k;
        boolean flag;
        flag = true;
        System.out.println("\tM\tE\tN\tU\n");
        System.out.println("1. RLE modificado: comprimir cadena");
        System.out.println("2. RLE modificada: descomprimir cadena");
        System.out.println("3. REL binario: comprimir cadena");
        System.out.println("4. REL binario: descomprimir cadena");
        System.out.println("5. salir");
       

        while (flag)
        {

            System.out.print("\nSeleccionar opcion::");
            opcion = input.nextInt();
            if (opcion == 6) {             
                System.exit(0);
                flag = false;
                break;
            } else {
                switch (opcion) {
                    case 1: 
                       String  cadena;
                        System.out.println("Ingrese unda cadena: ");
                        cadena = input.next();
                        rle.ObtenerRle(cadena);
                        rle.Compresion(rle.getCadena());
                        System.out.println("la cadena comprimida es: "+rle.getCadena());
                        
                        break;

                    case 2:
                       
                        System.out.println();
                     
                        break;

                    case 3:
                     System.out.println("Ingrese una cadena: ");
                        cadena = input.next();
                        System.out.println("la cadena comprimida es:"+rle.RLEbinario(cadena));
                        break;
                    case 4:
                        System.out.println("Ingrese una cadena binaria: ");
                        cadena = input.next();
                        System.out.println("la cadena descomprimida es: "+rle.RLEdescomprimir(cadena));
                        
                        
                        break;
                    case 5:
                      System.exit(0);
                        break;


                    default: 
                        System.out.println("\nError\n");
                        break;
                }
            }
        }
    }
    
}
