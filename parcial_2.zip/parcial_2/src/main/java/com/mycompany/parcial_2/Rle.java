/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.parcial_2;

import java.util.ArrayList;

/**
 *
 * @author datos
 */
public class Rle {
    private String cadena;
    private ArrayList<String>array;
    
    public void ObtenerRle(String cadena){
        String cadena_aux ="";
        int conta = 1;
        char carater_aux = 0;
        for(int i=0; i<cadena.length();i++){
            if(i>1){
                if(carater_aux == cadena.charAt(i)){
                    conta++;
                }
                else{
                    cadena_aux+= conta + carater_aux;
                    conta = 0;
                    carater_aux = cadena.charAt(i);    
                }
           
            }
            else{
                carater_aux  = cadena.charAt(i); 
            }   
        }
        cadena = cadena_aux;   
    }
    public void Compresion(String cadena){
        String binario,cadena_aux="", cadena_aux2="",cadena_aux3="";
        int num_ascii, size_bin, bit, bit2;
        
        for(int i=0; i<cadena.length();i++){
            num_ascii = cadena.charAt(i); // obtener el numero ascii
             binario = Integer.toBinaryString(num_ascii); // obtener el numero binario.
             size_bin = binario.length();
             bit = Integer.parseInt(String.valueOf(binario.charAt(size_bin-1)));
             bit2 = Integer.parseInt(String.valueOf(binario.charAt(size_bin-1)));
             int x = binario.length()-2;
             
             for(int j=0; j< x;i++){
                 cadena_aux2+=binario.charAt(j);
             }
             
             if(bit2 == 1){
                 cadena_aux3+=1;
             }
             else{
                 cadena_aux3+=0; 
             }
             
             if(bit == 1){
                 cadena_aux3+=1;
             }
             else{
                 cadena_aux3+=0;
             }
             cadena_aux2+=cadena_aux3;
             
             int contador = 0, num=0;
             for(int y=0;y<cadena_aux2.length(); y--){
                bit = Integer.parseInt(String.valueOf(cadena_aux2.charAt(i)));
                if(bit == 1){ //si el bit es uno se realiza la operacion siguiente 
                num += (int) Math.pow(2,contador);// la base dos elevado al contador se le suma al numero ascii
                }
             }
             
             char cararcter_ascii =(char)num;
             cadena_aux+=cararcter_ascii;            
        }
        cadena = cadena_aux;
        
    }
    public String RLEbinario(String cadena){
        ObtenerRle(cadena);
        cadena = getCadena();
        String binario,cadena_aux="", cadena_aux2="",cadena_aux3="";
        int num_ascii, size_bin, bit, bit2;
        
        for(int i=0; i<cadena.length();i++){
            num_ascii = cadena.charAt(i); // obtener el numero ascii
            binario = Integer.toBinaryString(num_ascii); // obtener el numero binario.
            cadena_aux+=binario;
            
        }
        return cadena_aux;          
    }
    public String RLEdescomprimir(String cadena){
        String cadena_principal = "";
        String cadena_binaria = cadena;
        char []cadena_ascii;
        int num_bits = cadena_binaria.length(), grupos_de_ocho, bits_ocupados, resto_de_bits,contador=0,num_ascii = 0, bit,size_cadena_ascii;
        
        grupos_de_ocho = num_bits / 8;
        bits_ocupados = grupos_de_ocho * 8;
        resto_de_bits = num_bits - bits_ocupados;
        if(resto_de_bits == 0){// si no hay bits restantes a la hora de formar los grupos
            cadena_ascii = new char[grupos_de_ocho];
            size_cadena_ascii = grupos_de_ocho;
        }
        else if(resto_de_bits > 0){ // si el resto de bits no incluidos en los grupos de 8 es mayor a 0
            cadena_ascii = new char[grupos_de_ocho+1];
            size_cadena_ascii = grupos_de_ocho +1;
        }
        else{// si no tiene grupos de 8 bits
            cadena_ascii = new char[num_bits];
            size_cadena_ascii = num_bits;
        }
      int aux = size_cadena_ascii;
      if(grupos_de_ocho > 0 ){// si se forma al menos un grupo de 8 bits
        for(int i=num_bits-1;i>resto_de_bits-1; i--){// se empieza a contar de derecha a izquierda
            bit = Integer.parseInt(String.valueOf(cadena_binaria.charAt(i))); // se obtiene el bit de la cadena 
            if(bit == 1){ //si el bit es uno se realiza la operacion siguiente 
                num_ascii += (int) Math.pow(2,contador);// la base dos elevado al contador se le suma al numero ascii
            }
            //si ya a recorrido los 8 bits 
            if(contador == 7){
                System.out.println(num_ascii);
                contador = 0;// el contador se vuelve a poner a cero 
                cadena_ascii[aux-1] =(char)num_ascii ; // se agrega el caracter ascii en el array desde la ultima posicion a la primera
                num_ascii = 0;
                aux--;
            }
            else{
            contador++;
            }
        }
        //si quedan resto de bit que no ingresan en un grupo de 8
        if(resto_de_bits != 0){
            contador = 0;
            num_ascii = 0;
            for(int i=resto_de_bits-1; i>=0; i--){
                bit = Integer.parseInt(String.valueOf(cadena_binaria.charAt(i)));
                if(bit == 1){ //si el bit es uno se realiza la operacion siguiente 
                num_ascii += (int) Math.pow(2,contador);// la base dos elevado al contador se le suma al numero ascii
            }
            //si ya a recorrido los bits
            if(contador == (resto_de_bits-1)){
               
                contador = 0;// el contador se vuelve a poner a cero 
                cadena_ascii[aux-1] =(char)num_ascii ; // se agrega el caracter ascii en el array desde la ultima posicion a la primera
                num_ascii = 0;
                aux--;
            }
            else{
            contador++;
            }
            }
           
            
        }
         
      }
      else{
          
            contador = 0;
            num_ascii = 0;
            for(int i=num_bits-1; i>=0; i--){
                bit = Integer.parseInt(String.valueOf(cadena_binaria.charAt(i)));
                if(bit == 1){ //si el bit es uno se realiza la operacion siguiente 
                num_ascii += (int) Math.pow(2,contador);// la base dos elevado al contador se le suma al numero ascii
            }
            //si ya a recorrido los bits
            if(contador == (num_bits-1)){
               
                contador = 0;// el contador se vuelve a poner a cero 
                cadena_ascii[aux-1] =(char)num_ascii ; // se agrega el caracter ascii en el array desde la ultima posicion a la primera
                num_ascii = 0;
                aux--;
            }
            else{
            contador++;
            }
            }
          
      }
      for(int i=0; i<size_cadena_ascii; i++){
                cadena_principal+=cadena_ascii[i];
            }
      return cadena_principal;
    }
    public String getCadena() {
        
        return cadena;
    }

    public void setCadena(String cadena) {
        this.cadena = cadena;
    }
    
    
}
